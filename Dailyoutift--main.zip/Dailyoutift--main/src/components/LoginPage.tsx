import { useState } from 'react'
import { signInWithPopup, type User } from 'firebase/auth'
import { Loader2, Sparkles } from 'lucide-react'
import { auth, googleProvider } from '../lib/firebase'

interface Props {
  onLogin: (user: User) => void
}

export default function LoginPage({ onLogin }: Props) {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function signIn() {
    if (!auth) return
    setLoading(true)
    setError('')
    try {
      const result = await signInWithPopup(auth, googleProvider)
      onLogin(result.user)
    } catch (e: unknown) {
      const code = (e as { code?: string })?.code ?? ''
      const msg = e instanceof Error ? e.message : String(e)
      if (code === 'auth/popup-closed-by-user' || msg.includes('popup-closed')) {
        setError('Popup closed — please try again')
      } else if (code === 'auth/unauthorized-domain') {
        setError('Domain not authorized. Go to Firebase Console → Authentication → Settings → Authorized domains → add daily-outfit-stylist.vercel.app')
      } else if (code === 'auth/operation-not-allowed') {
        setError('Google sign-in not enabled. Go to Firebase Console → Authentication → Sign-in method → enable Google.')
      } else if (code === 'auth/cancelled-popup-request') {
        setError('Another sign-in popup is open. Close it and try again.')
      } else {
        setError(`Sign-in error (${code || 'unknown'}): ${msg.substring(0, 100)}`)
      }
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-cream flex items-center justify-center p-6">
      <div className="bg-white rounded-3xl shadow-lg p-8 max-w-sm w-full">

        <div className="flex justify-center mb-6">
          <div className="w-16 h-16 bg-charcoal rounded-2xl flex items-center justify-center">
            <Sparkles className="w-8 h-8 text-white" strokeWidth={1.5} />
          </div>
        </div>

        <h1 className="text-2xl font-semibold text-charcoal text-center mb-2">
          Daily Stylist
        </h1>
        <p className="text-gray-400 text-sm text-center mb-8">
          Your AI wardrobe synced across all devices
        </p>

        <button
          onClick={signIn}
          disabled={loading}
          className="w-full flex items-center justify-center gap-3 bg-white border-2 border-gray-200 text-charcoal rounded-xl py-3.5 text-sm font-medium hover:border-gray-300 hover:bg-gray-50 transition-colors disabled:opacity-50"
        >
          {loading ? (
            <Loader2 className="w-5 h-5 animate-spin text-gray-400" />
          ) : (
            <svg className="w-5 h-5 flex-shrink-0" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
            </svg>
          )}
          {loading ? 'Signing in…' : 'Continue with Google'}
        </button>

        {error && (
          <div className="mt-3 bg-red-50 rounded-xl px-4 py-3">
            <p className="text-red-500 text-xs leading-relaxed">{error}</p>
          </div>
        )}

        <p className="text-[11px] text-gray-300 text-center mt-6">
          Your wardrobe stays private and syncs automatically
        </p>
      </div>
    </div>
  )
}
